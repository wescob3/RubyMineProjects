
#Author: William Ernesto Escobar Morales NetID: wescob3
#CS 474: Object Oriented Programming Languages and Environments
#Fall 2021
#First Ruby project
#
# Creating global variable that will hold the current class
# global variable
$current_class = Object

# Class that prints the "Object" class information
class Main_Object_Class
  #Merge_Sort array to sort an array of strings
  def merge_sort(myarray)
    #If there is only one element then is sorted and return
    if myarray.length <=1
      return myarray
    else
      mid = myarray.length/2# dividing array in 2
      half1 = merge_sort(myarray.slice(0...mid))# Assigning first part of array to half1
      half2 = merge_sort(myarray.slice(mid...myarray.length))# Assigning second part of array to half2
      merge(half1, half2)#calling merge method on both halves
    end
  end
  #merge method to sort
  def merge(myleft, myright)
    sortarray = []
    while !myleft.empty? && !myright.empty? do
      if myleft[0] < myright[0]#sorting elements
        sortarray.push(myleft.shift)
      else
        sortarray.push(myright.shift)
      end
    end
    return sortarray.concat(myleft).concat(myright)#concatinating elements of arrays
  end
  #Method to obtain the subclasses of the current class
  def get_subclasses
    nano = ObjectSpace.each_object(Class).select {|kl|kl<$current_class}
    myarr =[]
    nano.each do |item|
      myarr.append(item.to_s)
    end
    return merge_sort(myarr)
  end
  #Method to obtain the subclasses of the super current class
  def get_subclasses_super(superclas)
    nano = ObjectSpace.each_object(Class).select {|kl|kl<superclas}
    myarr =[]
    nano.each do |item|
      myarr.append(item.to_s)
    end
    return merge_sort(myarr)
  end
  #Method to get the methods of a class
  def get_methods
    #get the methods or private, public and protected and stored them in a separate array and then join them in the same array
    nano_private = $current_class.private_instance_methods(false)
    nano_public = $current_class.public_instance_methods(false)
    nano_protected = $current_class.protected_instance_methods(false)
    #myarr will hold all the data extracted by the variable nano_private, nano_public and nano_protected
    myarr =[]
    nano_private.each do |item|
      myarr.append(item.to_s+" <private>")
    end
    nano_public.each do |item|
      myarr.append(item.to_s+" <public>")
    end
    nano_protected.each do |item|
      myarr.append(item.to_s+" <protected>")
    end
    return merge_sort(myarr)
  end
  #Method to obtain the class's instance variables
  def get_instance_var
    nano = $current_class.instance_variables
    myarr =[]
    nano.each do |item|
      myarr.append(item.to_s)
    end
    return merge_sort(myarr)
  end

  #method to print information about the class
  def Print_Object_Class
    puts "\n                   The current class is #{$current_class.name}"
    if $current_class==Object
    puts "\r                   #{$current_class.name} is Root"
    else
      puts "\r                   The superclass is #{$current_class.superclass.name} "
    end

    puts "\r                   The subclasses of #{$current_class.name} are:"
    #Enumerating the items of my result and printing them to console
    get_subclasses.each_with_index do |item, index|
      puts "#{index+1}- #{item} "
    end
    puts "\r                   The Methods of #{$current_class.name} are:"
    #Enumerating the items of my result and printing them to console
    get_methods.each_with_index do |item, index|
      puts "#{index+1}- #{item} "
    end
    puts "\r                   The #{$current_class.name}'s instance variables are:"
    get_instance_var.each_with_index do |item, index|
      puts "#{index+1}- #{item} "
    end

  end
  #Method to get the n class from the list of subclasses
  def get_n_class(my_index)
    get_subclasses.each_with_index do |item, index|
      if (index+1)==my_index
        p( " THIS IS IMPORTANT************************************************************************************")
        $current_class=eval(item)
        return true
      end
    end
  end
  #Method to display only public class methods
  def get_publi_methods
    nano_public = $current_class.public_instance_methods(false)
    myarr =[]
    nano_public.each do |item|
      myarr.append(item.to_s+" <public>")
    end
    puts merge_sort(myarr)
  end
  #Method to find if given string is the name of a class
  def get_class_name(my_index)
    begin
        my_entered_class = eval(my_index)
        my_entered_class_superClass= my_entered_class.superclass
        get_subclasses_super(my_entered_class_superClass).each_with_index do |item, index|
          if item==my_index
            p( " The entered class has been found in the subclasses of the superclass")
            $current_class=eval(item)
            return true
          end
        end
      return false
        #The following code is to make the user enter only a class that belongs to the subclasses of the current class I decided to
        # not implement the code below because the pdf does not specify that the user must enter a subclass of the current class
      #get_subclasses.each_with_index do |item, index|
      #if item==my_index
      # p( " THIS IS IMPORTANT class name************************************************************************************")
      #$current_class=eval(item)
      # return true
      #end
      # end
    rescue
      return false
    end
  end


end



puts "***********************************************************************************************\r
*                                                                                             *\r
*                             Project 1 - Class Browser in Ruby                               *\r
*                                                                                             *\r
*  s — Display the five items of information above for the superclass of the current class    *\r
*  u n -Prints — The n-th subclass of the current class becomes the current class             *\r
*  m — This command prints a list of the public class methods defined in the current class    *\r
*  c aString — The input string must denote a class name                                      *\r
*  q — This command exits your browser                                                        *\r
*                                                                                             *\r
***********************************************************************************************\n"

class1obj = Main_Object_Class.new
class1obj.Print_Object_Class

loop do
  puts("---------------------------------------------------------------------------------------------------")
  puts( "\nEnter a command to proceed choose from {s , u, m, c, q} : ")
  user_input = gets
  my_user_input = user_input.split
  if my_user_input.first == "s"
    puts("You entered: s")
    #If current class is the Object class(the root) nothing is printed and the program asks the user to enter a command
    if $current_class== Object
      puts "You are in the Object class, Object is the root of the class hierarchy\r"
    elsif $current_class != Object
      $current_class= $current_class.superclass
      class2obj = Main_Object_Class.new
      class2obj.Print_Object_Class
    end
    #If user enters u n we find the n subclass of the current class and make it the current class
  elsif my_user_input.first == "u"
    puts("You entered: u")

    class3obj = Main_Object_Class.new
    if class3obj.get_n_class((my_user_input[1].to_i)) == true
      class3obj.Print_Object_Class
    else
      puts("n is out of bounds, please enter a valid index")
    end



  elsif my_user_input.first == "m"
    puts("You entered: m")
    puts("The following is a list of the current class public methods: \n")
    class4obj = Main_Object_Class.new
    class4obj.get_publi_methods


  elsif my_user_input.first == "c"
    puts("You entered: c")
    if my_user_input[1]=="Object"
      puts("Object is the root, enter another class name")
    else
      class5obj = Main_Object_Class.new
      if class5obj.get_class_name((my_user_input[1])) == true
        puts("The current class has been changed to: #{my_user_input[1]}")
        class5obj.Print_Object_Class
      end
    end


    #puts("The current class has been changed to: #{my_user_input[1]}")
    #class5obj = Main_Object_Class.new
    #if class5obj.get_class_name((my_user_input[1])) == true
    # class5obj.Print_Object_Class
    #else
    # puts("Class is not found in the subclasses of the current class")
    #end
  elsif my_user_input.first == "q"
    puts("You entered: q ----> Program closed")
    exit(0)
  else
    puts "Please enter a valid command {s, u, m, c, q}"
  end
end

